Nesta pasta, estão definidos mecanismos de tratamento de exceções destinados
a reforçar a separação entre a lógica de interface com o usuário e os demais módulos do sistema.
Isso é feito para garantir que a interação com o usuário ocorra apenas no módulo principal,
ajudando a preservar o encapsulamento.