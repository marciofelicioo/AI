OBJETIVO DO PROJETO: Encontrar a solução de menor custo e de menor tempo possível
para o problema dos contentores através do algoritmo de procura A* e respetiva
heurística.

AUTORES: Márcio Felício, Maria Anjos, Miguel Rosa

DATA: Refinado a 22/10/2024
