import java.util.*;

/**
 * Classe Platform: Esta classe contém construtores que criam objetos ContainerConfiguration
 * e o seu principal objetivo é criar sucessores de uma certa configuração para poder auxiliar
 * o método solve da classe BestFirst (Best First Search)
 * @author ...
 * @version 1.0
 * @inv Cada Contêiner tem de ter um custo associado caso seja configuração inicial
 */
public class Platform implements Ilayout, Cloneable {
    /**
     * Estrutura estática da classe ContainerOrganizer
     */
    public static final Comparator<Deque<Container>> compareChars = (s1, s2) -> {
        if (s1.isEmpty() && s2.isEmpty()) return 0;
        if (s1.isEmpty()) return -1;
        if (s2.isEmpty()) return 1;
        return String.valueOf(s1.peekFirst().getId()).compareTo(String.valueOf(s2.peekFirst().getId()));
    };
    private static Map<Character, Position> goalPositions = null;

    private static class Position {
        char base;
        int height;

        Position(char base, int height) {
            this.base = base;
            this.height = height;
        }
    }

    /**
     * Estrutura da classe ContainerOrganizer
     */
    private final List<Deque<Container>> stacks;
    private double cost;

    /**
     * Construtor por omissão
     */
    public Platform() {
        stacks = null;
        this.cost = 0;
    }

    /**
     * Construtor de inicialização
     */
    public Platform(String config) {
        stacks = new ArrayList<>();
        parseInput(config);
        this.cost = 0;
    }

    /**
     * Construtor de cópia para casos de encapsulamento de dados
     */
    public Platform(Platform other) {
        this.stacks = new ArrayList<>(other.stacks.size());

        for (Deque<Container> stack : other.stacks) {
            Deque<Container> newStack = new ArrayDeque<>(stack);
            this.stacks.add(newStack);
        }
        this.cost = other.getK();
    }

    private void parseInput(String config) {
        String[] stacksConfig = config.split(" ");
        for (String stackStr : stacksConfig) {
            Deque<Container> stack = new ArrayDeque<>();
            int length = stackStr.length();
            for (int i = 0; i < length; i++) {
                char containerId = stackStr.charAt(i);
                int movecost = 0;

                if (i + 1 < length && Character.isDigit(stackStr.charAt(i + 1))) {
                    movecost = Character.getNumericValue(stackStr.charAt(++i));
                }

                stack.addLast(new Container(containerId, movecost));
            }
            stacks.add(stack);
        }
        getSortedStacks();
    }

    /**
     * Getter para as stacks e setter para o custo de movimento de um contêiner
     * @return stacks
     */
    public List<Deque<Container>> getStacks() {
        return stacks;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * @return uma chave única para a instância criada
     */
    @Override
    public int hashCode() {
        int result = 1;
        for (Deque<Container> stack : stacks) {
            result = 31 * result + dequeHashCode(stack);
        }
        return result;
    }

    private int dequeHashCode(Deque<Container> deque) {
        int h = 1;
        for (Container c : deque) {
            h = 31 * h + (c == null ? 0 : c.hashCode());
        }
        return h;
    }

    /**
     * @return um clone de uma determinada instância com o auxílio do construtor de cópia
     */
    @Override
    public Platform clone() {
        return new Platform(this);
    }

    /**
     * @return representação textual da estrutura da instância
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (Deque<Container> stack : stacks) {
            sb.append("[");
            int count = 0;
            int size = stack.size();
            for (Container container : stack) {
                sb.append(container.toString());
                if (++count < size) {
                    sb.append(", ");
                }
            }
            sb.append("]\n");
        }
        return sb.toString();
    }

    /**
     * @return as configurações feitas através de uma configuração pai
     */
    @Override
    public List<Ilayout> children() {
        List<Ilayout> littleOnes = new ArrayList<>();
        int numStacks = stacks.size();
        for (int i = 0; i < numStacks; i++) {
            Deque<Container> fromStack = stacks.get(i);
            if (!fromStack.isEmpty()) {
                for (int j = 0; j < numStacks; j++) {
                    if (i != j) {
                        Platform newState = new Platform(this);  // Clone current state
                        Deque<Container> newFromStack = newState.stacks.get(i);
                        Deque<Container> newToStack = newState.stacks.get(j);

                        Container movedContainer = newFromStack.removeLast();
                        newToStack.addLast(movedContainer);

                        if (newFromStack.isEmpty()) {
                            newState.stacks.remove(i);
                            if (i < j) {
                                // Ajustar índice após remoção
                                // Nenhuma ação necessária aqui porque estamos trabalhando com uma cópia
                            }
                        }

                        newState.setCost(movedContainer.getCost());
                        littleOnes.add(newState);
                    }
                }

                // Mover para uma nova pilha
                Platform newState = new Platform(this);  // Clone current state
                Deque<Container> newFromStack = newState.stacks.get(i);

                Container movedContainer = newFromStack.removeLast();

                Deque<Container> newStack = new ArrayDeque<>();
                newStack.addLast(movedContainer);
                newState.stacks.add(newStack);

                if (newFromStack.isEmpty()) {
                    newState.stacks.remove(i);
                }

                newState.setCost(movedContainer.getCost());
                newState.getSortedStacks();
                littleOnes.add(newState);
            }
        }
        return littleOnes;
    }

    /**
     * Verifica se a configuração l é a configuração objetivo
     * @param l representa a configuração objetivo que queremos testar
     * @return true se forem iguais e false caso contrário
     */
    @Override
    public boolean isGoal(Ilayout l) {
        return this.equals(l);
    }

    /**
     * Retorna o custo de movimento de um certo contêiner
     */
    @Override
    public double getK() {
        return this.cost;
    }

    public double computeHeuristic(Ilayout goalLayout) {
        Platform goalPlatform = (Platform) goalLayout;

        int stacksWithPrimeContainers = countStacksWithPrimeContainers(goalPlatform);

        if (goalPositions == null) {
            cacheGoalPositions(goalPlatform);
        }

        double h = 0;

        for (int i = 0; i < this.stacks.size(); i++) {
            Deque<Container> stack = this.stacks.get(i);
            char currentBase = stack.isEmpty() ? '\0' : stack.peekFirst().getId();

            int j = 0;
            for (Container container : stack) {
                Position goalPosition = goalPositions.get(container.getId());
                if (goalPosition == null) {
                    j++;
                    continue;
                }

                if (stacksWithPrimeContainers == 2 && !(j == 0 && goalPosition.height == 0) && !(j > 0 && goalPosition.height == j)) {
                    h += container.getCost();
                }

                if (goalPosition.base != currentBase) {
                    h += container.getCost();
                } else if (goalPosition.height != j) {
                    h += 2 * container.getCost();
                }
                j++;
            }
        }
        return h;
    }

    private int countStacksWithPrimeContainers(Platform goalPlatform) {
        int count = 0;
        for (Deque<Container> stack : goalPlatform.getStacks()) {
            if (isPrime(stack.size())) {
                count++;
            }
        }
        return count;
    }

    private boolean isPrime(int number) {
        if (number <= 5) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }


    private void cacheGoalPositions(Platform goal) {
        goalPositions = new HashMap<>();
        for (Deque<Container> stack : goal.stacks) {
            char base = stack.isEmpty() ? '\0' : stack.peekFirst().getId();
            int height = 0;
            for (Container container : stack) {
                goalPositions.put(container.getId(), new Position(base, height));
                height++;
            }
        }
    }

    /**
     * Verifica se as configurações são iguais
     * @param o representa uma configuração que será testada com o this (instância receptora)
     * @return true caso sejam iguais e false caso contrário
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Platform)) return false;
        Platform other = (Platform) o;
        if (this.stacks.size() != other.stacks.size()) {
            return false;
        }
        for (int i = 0; i < this.stacks.size(); i++) {
            Deque<Container> thisStack = this.stacks.get(i);
            Deque<Container> otherStack = other.stacks.get(i);
            if (!dequesAreEqual(thisStack, otherStack)) {
                return false;
            }
        }
        return true;
    }

    private boolean dequesAreEqual(Deque<Container> d1, Deque<Container> d2) {
        if (d1.size() != d2.size()) {
            return false;
        }
        Iterator<Container> it1 = d1.iterator();
        Iterator<Container> it2 = d2.iterator();
        while (it1.hasNext()) {
            Container c1 = it1.next();
            Container c2 = it2.next();
            if (!c1.equals(c2)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Ordena as stacks segundo o id dos contêineres, ignorando as stacks vazias.
     */
    private void getSortedStacks() {
        stacks.sort(Platform.compareChars);
    }
}