public final class Container {
    private final char id;
    private final int containerCost;

    public Container(char id, int cost) {
        this.id = id;
        this.containerCost = cost;
    }

    public int getCost() {
        return containerCost;
    }

    public char getId() {
        return id;
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Container)) return false;
        Container other = (Container) obj;
        return this.id == other.id;
    }

    @Override
    public Container clone() {
        return this; // Como a classe é imutável, podemos retornar this
    }

    @Override
    public String toString() {
        return String.valueOf(id);
    }
}