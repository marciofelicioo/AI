import java.util.*;
public class AStar {
    protected Queue<State> abertos;
    private Map<Ilayout,State> abertosMap;
    private Set<Ilayout> fechados;
    private State actual;
    private Ilayout objective;

    public static class State {
        private Ilayout layout;
        private State father;
        private double g;
        Map<Ilayout, Double> heuristicCache = new HashMap<>();

        public State(Ilayout l, State n) {
            this.layout = l;
            this.father = n;
            if (this.father != null)
                this.g = this.father.getG() + l.getK();
            else
                this.g = 0.0;
        }

        // F(n) = G(n) + H(n)
        public double getF(Ilayout objective) {
            return this.g + computeHeuristic(this.layout,objective);
        }

        public double getG() {
            return this.g;
        }

        public Ilayout getLayout() {
            return this.layout;
        }

        public State getFather() {
            return this.father;
        }

        @Override
        public int hashCode() {
            return toString().hashCode();
        }

        public double computeHeuristic(Ilayout layout,Ilayout goal) {
            if (heuristicCache.containsKey(layout)) {
                return heuristicCache.get(layout);
            }
            double heuristicValue = layout.computeHeuristic(goal);
            heuristicCache.put(layout, heuristicValue);
            return heuristicValue;
        }
        @Override
        public boolean equals(Object obj) {
            if (obj == null) return false;
            if (this.getClass() != obj.getClass()) return false;
            State other = (State) obj;
            return layout.equals(other.layout);
        }

        @Override
        public String toString() {
            return this.layout.toString();
        }
    }

    final private List<State> sucessores(State n) {
        List<State> sucs = new ArrayList<>();
        List<Ilayout> children = n.getLayout().children();
        int i = 0;
        for (Ilayout e : children) {
            i++;
            if ((n.getFather() == null || !e.equals(n.getFather().getLayout()))
                    && !fechados.contains(e)) {
                State nn = new State(e, n);
                sucs.add(nn);
            }
            if(i == 10000) break;
        }
        return sucs;
    }

    /**
     * MÃ©todo que implementa o A*.
     *
     * @param initial representa a configuraÃ§Ã£o inicial
     * @param goal    representa a configuraÃ§Ã£o objetivo
     * @return O estado objetivo alcanÃ§ado
     */
    public State solve(Ilayout initial, Ilayout goal) {
        this.objective = goal;
        abertos = new PriorityQueue<>(10, Comparator.comparingDouble((State s) -> s.getF(this.objective))
                .thenComparing(s -> s.computeHeuristic(s.getLayout(),objective))
        );

        abertosMap = new HashMap<>();
        fechados = new HashSet<>();
        State initialState = new State(initial, null);
        abertos.add(initialState);
        abertosMap.put(initial,initialState);

        while (!abertos.isEmpty()) {
            actual = abertos.poll();
//            System.out.println(actual);
            abertosMap.remove(actual.getLayout());
//            if (actual.getLayout().isGoal(objective)) {
//                return actual;
//            }

            fechados.add(actual.getLayout());

            List<State> sucs = sucessores(actual);
            for (State successor : sucs) {

                if (!fechados.contains(successor.getLayout()) && !abertosMap.containsKey(successor.getLayout())) {
                    if(successor.getLayout().isGoal(objective))
                    {
                        return successor;
                    }
                    abertos.add(successor);
                    abertosMap.put(successor.getLayout(),successor);
                }
            }
        }
        return null;
    }


}